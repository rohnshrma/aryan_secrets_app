const bodyParser = require("body-parser");
const express= require("express")
const app = express();
const PORT = 3000


// middlewares
app.set("view engine","ejs")
app.use(express.static("public"))
app.use(bodyParser.urlencoded({extended:true}))

// routes
// home
app.get("/",(req,res)=>{
    res.render("home")
})

// signup
app.get("/signup",(req,res)=>{
    res.render("signup")
})


// login
app.get("/login",(req,res)=>{
    res.render("login")
})

// setupServer
app.listen(PORT , ()=>{
    console.log(`Server started on port : ${PORT}`)
})